use company;

truncate department;
truncate dependent;
truncate dept_locations;
truncate employee;
truncate location;
truncate project;
truncate works_on;