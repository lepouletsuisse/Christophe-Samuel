var searchData=
[
  ['main',['main',['../main_8cpp.html#a0ddf1224851353fc92bfbff6f499fa97',1,'main.cpp']]],
  ['mainwindow',['MainWindow',['../class_main_window.html#ae57a3f999fc7bdfca797a1e3370ca9af',1,'MainWindow']]]
];
