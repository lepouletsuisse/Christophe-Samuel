var searchData=
[
  ['min',['min',['../mainwindow_8cpp.html#ac6afabdc09a49a433ee19d8a9486056d',1,'mainwindow.cpp']]]
];
