var searchData=
[
  ['initialize',['initialize',['../class_biking_interface.html#a2ccf1cb82670bc369434a43c87af47ea',1,'BikingInterface']]]
];
