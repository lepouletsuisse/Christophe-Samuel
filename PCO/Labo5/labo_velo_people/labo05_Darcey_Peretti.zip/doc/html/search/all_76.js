var searchData=
[
  ['vantravel',['vanTravel',['../class_biking_interface.html#ac10c743ca48001f2d3eb87b30eda8942',1,'BikingInterface::vanTravel()'],['../class_bike_display.html#ab4311e7c7dcdec30947fa80204eb2814',1,'BikeDisplay::vanTravel()'],['../class_main_window.html#a44eac41a247e6498615ff210f541b0bc',1,'MainWindow::vanTravel()']]],
  ['vanwidth',['VANWIDTH',['../display_8cpp.html#aa2e4e4b6913cb0fa17b4b602cceb2462',1,'display.cpp']]]
];
