var searchData=
[
  ['nbpersonicons',['NBPERSONICONS',['../display_8cpp.html#a4f3e8185d0367b0f8f4c54f890e616f0',1,'display.cpp']]],
  ['nbsites',['NBSITES',['../main_8cpp.html#af8e98f5add8c2d585556c0cc3066f86b',1,'main.cpp']]]
];
